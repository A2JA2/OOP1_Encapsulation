﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP1_Encapsulation
{
    class Program
    {
        //Encapsulation and creating multiple objects
        public class Fish
        {
            //member variables
            private string name;
            private int age;
            private string colour;

            //member methods
            //setter and getter methods
            //store the argument value
            public void setValues(string name, int age, string colour)
            {
                this.name = name;
                this.age = age;
                this.colour = colour;
            }
            //retrieve the stored value
            public string getName() { return name; }
            public int getAge() { return age; }
            public string getColour() { return colour; }
            //other methods.
            public string speak() { return "\nBLUB, BLUB\n"; }
        }
        static void Main(string[] args)
        {
            //create an instancce of the fish class
            Fish Squid = new Fish();
            //create a second instance of the fish class
            Fish Octo = new Fish();

            //call the new instance object's setter method.
            //to intialise all its variable members.
            Squid.setValues("Squid", 10, "Red");
            Octo.setValues("Octo", 7, "Blue");

            //retrieve all the properties of the new object
            string tagS = String.Format("{0} is {1} years old {2} fish",
                Squid.getName(),
                Squid.getAge(),
                Squid.getColour());

            //retrieve all the properties of the new object
            string tagO = String.Format("{0} is {1} years old {2} fish",
                Octo.getName(),
                Octo.getAge(),
                Octo.getColour());

            //display the properties and call the speak method
            Console.WriteLine(tagS + Squid.speak());
            Console.WriteLine(tagO + Octo.speak());
            Console.ReadKey();
        }
    }
}
